import { motion } from 'framer-motion';

export default function About() {
  const skills = [
    {
      category: "Languages",
      icon: "fa-code",
      items: [
        { name: "Python", level: 95 },
        { name: "JavaScript / TypeScript", level: 90 },
        { name: "Go", level: 75 },
      ],
    },
    {
      category: "AI & Automation",
      icon: "fa-robot",
      items: [
        { name: "LangChain / LLMs", level: 90 },
        { name: "OpenAI API", level: 85 },
        { name: "TensorFlow / PyTorch", level: 75 },
      ],
    },
    {
      category: "Frameworks & Libraries",
      icon: "fa-layer-group",
      items: [
        { name: "React / Next.js", level: 95 },
        { name: "Node.js / Express", level: 90 },
        { name: "Django / FastAPI", level: 80 },
      ],
    },
    {
      category: "Databases & DevOps",
      icon: "fa-database",
      items: [
        { name: "PostgreSQL / MongoDB", level: 90 },
        { name: "Docker / Kubernetes", level: 85 },
        { name: "AWS / GCP", level: 80 },
      ],
    },
  ];

  return (
    <section className="min-h-screen bg-gray-50 px-6 py-20 flex flex-col items-center overflow-hidden">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <span className="text-sm font-medium text-indigo-600 bg-indigo-50 px-4 py-1 rounded-full">
          Skills & Expertise
        </span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mt-4">
          My Digital Toolkit
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto mt-3">
          A curated collection of the languages, frameworks, and technologies I
          use to build modern, scalable, and intelligent applications.
        </p>
      </motion.div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 w-full max-w-5xl">
        {skills.map((section, index) => (

          <motion.div
            key={section.category}
            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="bg-white shadow-md rounded-lg p-6 hover:border cursor-pointer hover:border-indigo-200 transition-colors"
          >
            <h3 className="flex items-center gap-2 text-xl font-semibold text-gray-900 mb-6">
              <i className={`fa-solid ${section.icon} text-indigo-600`}></i>
              {section.category}
            </h3>

            <div className="space-y-5">
              {section.items.map((skill) => (
                <div key={skill.name}>
                  <div className="flex justify-between text-sm font-medium text-gray-700 mb-1">
                    <span>{skill.name}</span>
                    <span>{skill.level}%</span>
                  </div>
                  <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
                      className="h-full bg-indigo-600 rounded-full"
                    ></motion.div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>

  )
}