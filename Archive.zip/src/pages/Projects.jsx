import { useState } from "react";
import { motion } from "framer-motion";
import FilterBar from "../components/FilterBar";
import ProjectCard from "../components/ProjectCard";

const allProjects = [
  {
    title: "AI Customer Service Chatbot",
    description: "A conversational AI for automated support and queries.",
    tags: ["Python", "LangChain", "React"],
    category: "AI/Automation",
    image: "https://placehold.co/600x400",
    demo: "#",
    code: "#",
  },
  {
    title: "E-commerce Platform",
    description: "A bespoke store with a custom CMS built for scalability.",
    tags: ["Next.js", "Node.js", "PostgreSQL"],
    category: "Fullstack",
    image: "https://placehold.co/600x400",
    demo: "#",
    code: "#",
  }
];

export default function Projects() {
  const [selected, setSelected] = useState("All");

  const categories = [...new Set(allProjects.map((p) => p.category))];
  const filtered =
    selected === "All"
      ? allProjects
      : allProjects.filter((p) => p.category === selected);

  return (
    <section className="pt-32 pb-20 px-6 bg-gray-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Selected Projects</h2>
        <p className="text-gray-600 max-w-2xl mx-auto text-lg">A collection of fullstack and AI-powered solutions built with modern technologies.</p>
      </motion.div>

      <FilterBar categories={categories} selected={selected} onSelect={setSelected} />

      <motion.div
        layout
        className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto"
      >
        {filtered.map((project, index) => (
          <motion.div
            layout
            key={project.title}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <ProjectCard project={project} />
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
