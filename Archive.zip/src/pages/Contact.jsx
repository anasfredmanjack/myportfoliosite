import { useState } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function Contact() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        const toastId = toast.loading('Sending message...');

        try {
            await axios.post('/api/contact', formData);
            toast.success('Message sent successfully!', { id: toastId });
            setFormData({ name: '', email: '', subject: '', message: '' });
        } catch (error) {
            console.error(error);
            toast.error('Failed to send message. Please try again.', { id: toastId });
        } finally {
            setLoading(false);
        }
    };

    return (
        <section className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4 py-20 overflow-hidden">
            {/* Title */}
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-center mb-12"
            >
                <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-3">
                    Get In <span className="text-indigo-600">Touch</span>
                </h1>
                <p className="text-gray-600 max-w-xl mx-auto">
                    I'm always open to discussing new projects, creative ideas, or
                    opportunities to be part of your vision.
                </p>
            </motion.div>

            {/* Contact Form */}
            <motion.form
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="bg-white shadow-xl rounded-2xl w-full max-w-2xl p-6 md:p-10 space-y-5 border border-gray-100"
                onSubmit={handleSubmit}
            >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Name"
                        className="border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                        required
                    />
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Email"
                        className="border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                        required
                    />
                </div>

                <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Subject"
                    className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    required
                />

                <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="6"
                    placeholder="Message"
                    className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    required
                ></textarea>

                <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-all transform hover:scale-[1.02] disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {loading ? 'Sending...' : 'Send Message'}
                </button>
            </motion.form>

            {/* Socials */}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex gap-6 mt-12 text-gray-600 text-2xl"
            >
                <a href="#" className="hover:text-indigo-600 transition-colors transform hover:scale-110">
                    <i className="fa-brands fa-linkedin"></i>
                </a>
                <a href="#" className="hover:text-indigo-600 transition-colors transform hover:scale-110">
                    <i className="fa-brands fa-github"></i>
                </a>
                <a href="#" className="hover:text-indigo-600 transition-colors transform hover:scale-110">
                    <i className="fa-brands fa-twitter"></i>
                </a>
            </motion.div>

            {/* Download Resume Button */}
            <motion.a
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                href="/resume.pdf"
                download
                className="mt-8 inline-flex items-center gap-2 bg-gray-900 text-white px-6 py-3 rounded-full hover:bg-gray-800 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="m12 16l-5-5l1.4-1.45l2.6 2.6V4h2v8.15l2.6-2.6L17 11zm-6 4q-.825 0-1.412-.587T4 18v-3h2v3h12v-3h2v3q0 .825-.587 1.413T18 20z" /></svg>
                <span>Download Resume</span>
            </motion.a>

        </section>
    );
}