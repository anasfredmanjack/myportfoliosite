import { motion } from 'framer-motion';

export default function ProjectCard({ project }) {
  return (
    <motion.div
      whileHover={{ y: -10, rotateX: 2, rotateY: 2, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300 }}
      className="bg-white rounded-xl shadow-lg border border-indigo-100 p-5 flex flex-col h-full transform-gpu"
    >
      <div className="overflow-hidden rounded-lg mb-4">
        <motion.img
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.5 }}
          src={project.image}
          alt={project.title}
          className="w-full h-48 object-cover"
        />
      </div>
      <h3 className="text-xl font-bold mb-2 text-gray-900">{project.title}</h3>
      <p className="text-gray-600 mb-4 flex-grow">{project.description}</p>

      <div className="flex flex-wrap gap-2 mb-6">
        {project.tags.map((tag) => (
          <span key={tag} className="text-xs font-medium bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full">{tag}</span>
        ))}
      </div>

      <div className="flex justify-between items-center pt-4 border-t border-gray-100 mt-auto">
        <a href={project.demo} target="_blank" rel="noreferrer" className="text-indigo-600 font-semibold hover:text-indigo-800 flex items-center gap-1 transition-colors">
          <span>Live Demo</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
        </a>
        <a href={project.code} target="_blank" rel="noreferrer" className="text-gray-600 font-semibold hover:text-gray-900 flex items-center gap-1 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
          <span>Code</span>
        </a>
      </div>
    </motion.div>
  );
}
